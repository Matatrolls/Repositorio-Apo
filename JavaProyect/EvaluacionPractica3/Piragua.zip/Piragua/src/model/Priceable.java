package model;

public interface Priceable {
    String priceable(int nights);
}
